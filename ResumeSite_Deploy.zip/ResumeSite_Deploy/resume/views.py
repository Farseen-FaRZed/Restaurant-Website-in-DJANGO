from django.shortcuts import render


def resume_view(request):
    resume_data = {
        'name': 'Aisha Rahman',
        'age': 24,
        'gender': 'female',
        'email': 'aisha.rahman@example.com',
        'about': 'Front-end developer who enjoys building clean, simple interfaces.',
        'skills': ['Python', 'Django', 'JavaScript', 'HTML & CSS', 'Git'],
        'education': {
            'degree': 'B.Tech in Computer Science',
            'institution': 'Calicut University',
            'year': '2024',
        },
    }
    return render(request, 'resume/resume.html', {'resume': resume_data})
